package com.example.atividade

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
